from zmqRemoteApi_IPv6 import RemoteAPIClient
import keyboard

# 远程API客户端连接
client = RemoteAPIClient('localhost', 23000)

# 获取仿真对象
sim = client.getObject('sim')

# 启动仿真
sim.startSimulation()

# 获取关节和轮的句柄
frontLeftSteeringJoint = sim.getObject('/frontLeftJoint1')
frontRightSteeringJoint = sim.getObject('/frontRightJoint1')
frontLeftWheel = sim.getObject('/frontLeftJoint2')
frontRightWheel = sim.getObject('/frontRightJoint2')
rearLeftWheel = sim.getObject('/rearLeftJoint')
rearRightWheel = sim.getObject('/rearRightJoint')

# 设置前轮转向角度
def setFrontWheelSteeringAngle(steeringAngle):
    sim.setJointTargetPosition(frontLeftSteeringJoint, steeringAngle)
    sim.setJointTargetPosition(frontRightSteeringJoint, steeringAngle)

# 设置所有轮的速度
def setAllWheelSpeed(speed):
    sim.setJointTargetVelocity(frontLeftWheel, speed)
    sim.setJointTargetVelocity(frontRightWheel, speed)
    sim.setJointTargetVelocity(rearLeftWheel, speed)
    sim.setJointTargetVelocity(rearRightWheel, speed)

# 初始化运动变量
steeringAngle = 0
speed = 0

# 常量定义
SPEED_FORWARD = -20
SPEED_BACKWARD = 20
STEERING_ANGLE_LEFT = 0.3
STEERING_ANGLE_RIGHT = -0.3

# 主循环
while True:
    # 检测键盘输入
    if keyboard.is_pressed('w'):
        # 前进
        speed = SPEED_FORWARD
    elif keyboard.is_pressed('s'):
        # 后退
        speed = SPEED_BACKWARD
    else:
        # 停止
        speed = 0

    if keyboard.is_pressed('a'):
        # 左转
        steeringAngle = STEERING_ANGLE_LEFT
    elif keyboard.is_pressed('d'):
        # 右转
        steeringAngle = STEERING_ANGLE_RIGHT
    else:
        # 直行
        steeringAngle = 0

    if keyboard.is_pressed('q'):
        break  # 退出

    # 设置前轮转向角度
    setFrontWheelSteeringAngle(steeringAngle)
    
    # 设置所有轮的速度
    setAllWheelSpeed(speed)

# 停止仿真
sim.stopSimulation()
